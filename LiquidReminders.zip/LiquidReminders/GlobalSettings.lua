local _, LRP = ...

LRP.gs = {
    debug = false, -- Debug mode adds some additional features
    visual = {
        font = "Interface\\Addons\\LiquidReminders\\Media\\Fonts\\PTSansNarrow.ttf",
        fontFlags = "",
        borderColor = {r = 0.3, g = 0.3, b = 0.3}
    }
}
